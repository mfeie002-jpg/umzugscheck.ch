# Randomized Multi-Agent Funnel Testing Tool (umzugscheck.ch)

A local, production-ready CLI tool that:

1) deterministically dispatches a **persona + gateway + policy** assignment, and
2) runs a real **Playwright** browser session to explore the funnel, and
3) stores structured artifacts per run, and
4) aggregates results into **CSV + Markdown leaderboards**.

This is designed to help you rank funnels and quickly detect failures across many entry pages.

---

## Folder structure

```text
umzugscheck-funnel-testing-tool/
  src/
    cli/            # npm run dispatch|run|report entrypoints
    dispatcher/     # deterministic assignment (deck/random/weighted)
    runner/         # Playwright executor + heuristics
    reporting/      # CSV + Markdown aggregation
    shared/         # schemas, RNG, fs utils
  data/
    gateways.json
    personas.json
  runs/
    <run_id>/
      run.config.json
      assignment.snapshot.json
      result.json
      screenshots/
      trace.zip?         # optional
      network.har?       # optional
  reports/
    summary.csv
    leaderboard.md
    persona_gateway_heatmap.csv
    dropoffs.csv
  schemas/
    runConfig.schema.json
    runResult.schema.json
```

---

## Install

From inside this folder:

```bash
npm install
npm run playwright:install
```

Notes:
- `playwright:install` downloads browser binaries.
- If you’re on Linux and hit missing deps, keep `--with-deps` (already included).

---

## Data files

### `data/gateways.json`
Each gateway is a Google entry page / landing URL:

```json
{
  "gateway_id": "gw-de-umzugsofferten-v9",
  "keyword_cluster": "umzugsofferten",
  "landing_url": "https://umzugscheck.ch/umzugsofferten-v9",
  "intent": "Get multiple moving offers with minimal friction",
  "language": "de",
  "priority_weight": 4,
  "enabled": true
}
```

### `data/personas.json`
Each persona models click behavior and device type:

```json
{
  "persona_id": "p-de-urgent-family",
  "name": "Overwhelmed Family Fabienne",
  "traits": ["time-poor", "stressed", "needs guidance"],
  "budget": "medium",
  "urgency": 5,
  "trust_level": 4,
  "device": "mobile",
  "language": "de",
  "click_bias_weights": { "main": 0.75, "secondary": 0.15, "escape": 0.10 },
  "enabled": true
}
```

**Templates** for up to 20 gateways/personas are included in the JSON files with `"enabled": false`.

---

## Seeded randomness + reproducibility

Determinism rules:

- The dispatcher seeds its RNG with:

```text
seed_material = `${run_id}::${seed}::dispatch`
```

- The runner seeds its decision RNG with:

```text
seed_material = `${run_id}::${seed}::run`
```

So:
- **same run_id + same seed => same selection + same click decisions**
- every per-step decision uses a forked RNG (e.g. `...::run::step7`) so the run is stable even if you add logging.

Deck mode uses a persisted deck state at `runs/_state/deck.json` to guarantee **no repeats until the deck is exhausted**, then reshuffles.

---

## CLI usage

### 1) Dispatch a run config

```bash
npm run dispatch
```

Output: `runs/<run_id>/run.config.json` and `assignment.snapshot.json`.

Options:

```bash
npm run dispatch -- --mode deck
npm run dispatch -- --mode random
npm run dispatch -- --mode weighted

npm run dispatch -- --seed my-seed
npm run dispatch -- --headful
npm run dispatch -- --trace
npm run dispatch -- --har
npm run dispatch -- --submit        # allow final submission (default is safe dry-run)
```

### 2) Execute a run

```bash
npm run run -- --run_id <run_id>
```

Artifacts:
- `runs/<run_id>/screenshots/*`
- `runs/<run_id>/result.json`
- optional `trace.zip` / `network.har`

### 3) Aggregate reports

```bash
npm run report
```

Outputs in `/reports`:
- `summary.csv` (1 row per run)
- `leaderboard.md` (top/bottom gateways + dropoff reasons)
- `persona_gateway_heatmap.csv` (pivot-friendly matrix)
- `dropoffs.csv`

---

## Running 100 tests

### Option A (simple bash loop)

```bash
for i in $(seq 1 100); do
  RUN_ID=$(npm run dispatch --silent | node -e "let s='';process.stdin.on('data',d=>s+=d);process.stdin.on('end',()=>console.log(JSON.parse(s).run_id));")
  npm run run -- --run_id "$RUN_ID"
done

npm run report
```

### Option B (dispatch 100 at once)

```bash
npm run dispatch -- --count 100
# then run each run_id listed in the JSON output
```

---

## Interpreting `result.json`

Key fields:
- `scores` (1–5): `intent_match`, `trust`, `friction`, `clarity`, `mobile_usability`, `conversion_confidence`
- `verdict`: `WINNER | PROMISING | FAIL | BLOCKER`
- `dropoff_reason`: why the flow ended
- `fix_recommendation`: a first-pass remediation hint
- `steps`: structured event log with screenshots per step

A run is classified as **BLOCKER** if it cannot proceed due to errors (server errors, bot blocks, no clickable actions detected, click failures, etc.).

---

## Repo integration

In your existing GitHub repo:

1. Copy this folder into the repo (recommended location: `tools/funnel-testing/`).
2. Ensure your CI/dev machine can run Playwright (or skip runner in CI for now).
3. Add documentation link from your main repo README.

---

## Next improvements (roadmap)

1. **Smarter action detection**
   - learn stable selectors per gateway from earlier runs
   - use accessibility snapshots to avoid visual ambiguity
2. **Better form completion**
   - page-specific adapters for your main funnels (while keeping the generic fallback)
3. **Parallel runs**
   - worker pool to run N Playwright sessions concurrently
4. **CI mode**
   - nightly scheduled smoke runs for top gateways
5. **Advanced policies**
   - persona-specific “hesitation” delays
   - probabilities that change by step (early exploration vs late commitment)
6. **Trend reporting**
   - compare this week vs last week, detect regressions per gateway

---

## Safety defaults

By default, the tool runs in **dry-run mode** (`options.dryRun=true`) and stops when it detects a likely final submit CTA.

If you explicitly want real submission testing, dispatch with:

```bash
npm run dispatch -- --submit
```

(Still uses clearly fake data: email at `example.com` + `[TEST]` prefix in name.)
