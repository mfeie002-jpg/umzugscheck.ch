#!/usr/bin/env node
import { Command } from 'commander';
import { dispatchRun } from '../dispatcher/index.js';
import { generateRunId, stableShortHash } from '../shared/rng.js';
import { createLogger } from '../shared/logger.js';

const log = createLogger((process.env.LOG_LEVEL as any) || 'info');

const program = new Command();
program
  .name('dispatch')
  .description('Create a deterministic run assignment (run config JSON)')
  .option('--run_id <id>', 'Run ID (defaults to generated timestamp-based id)')
  .option('--seed <seed>', 'Seed string used with run_id for deterministic selection')
  .option('--mode <mode>', 'Dispatch mode: deck | random | weighted', 'deck')
  .option('--count <n>', 'Create N run configs', '1')
  .option('--no-match_language', 'Allow persona language to differ from gateway language')
  .option('--headful', 'Run browser headful when executing later (sets headless=false)')
  .option('--trace', 'Enable Playwright trace')
  .option('--har', 'Enable HAR capture')
  .option('--submit', 'Allow final form submission (dryRun=false)')
  .option('--maxSteps <n>', 'Max click/interaction steps', '25')
  .option('--maxTimeMs <ms>', 'Max time per run in ms', '120000')
  .option('--stepTimeoutMs <ms>', 'Per-step timeout in ms', '15000');

program.parse(process.argv);
const opts = program.opts();

const count = Number.parseInt(opts.count, 10);
if (!Number.isFinite(count) || count <= 0) {
  throw new Error(`Invalid --count: ${opts.count}`);
}

async function main() {
  const created: { run_id: string; seed: string }[] = [];
  for (let i = 0; i < count; i++) {
    const baseRunId = (opts.run_id as string | undefined) ?? generateRunId();
    const run_id = count > 1 ? `${baseRunId}-${String(i + 1).padStart(3, '0')}` : baseRunId;

    // If user didn't provide a seed, create one that is stable and recorded.
    const seed = (opts.seed as string | undefined) ?? stableShortHash(`seed::${run_id}`, 16);

    const { runConfig, runDir } = await dispatchRun({
      run_id,
      seed,
      mode: opts.mode,
      matchLanguage: opts.match_language !== false,
      options: {
        headless: !opts.headful,
        enableTrace: Boolean(opts.trace),
        enableHar: Boolean(opts.har),
        dryRun: !Boolean(opts.submit),
        maxSteps: Number.parseInt(opts.maxSteps, 10),
        maxTimeMs: Number.parseInt(opts.maxTimeMs, 10),
        stepTimeoutMs: Number.parseInt(opts.stepTimeoutMs, 10)
      }
    });

    created.push({ run_id: runConfig.run_id, seed: runConfig.seed });
    log.info(`Dispatched run_id=${runConfig.run_id} mode=${runConfig.dispatcher.mode} -> ${runDir}`);
  }

  // Friendly output for scripting
  if (count === 1) {
    const single = created[0];
    console.log(JSON.stringify({ ...single }, null, 2));
  } else {
    console.log(JSON.stringify({ runs: created }, null, 2));
  }
}

main().catch((err) => {
  log.error(err?.message ?? String(err));
  process.exitCode = 1;
});
