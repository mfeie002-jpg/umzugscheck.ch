#!/usr/bin/env node
import { Command } from 'commander';
import { generateReports } from '../reporting/index.js';
import { createLogger } from '../shared/logger.js';

const log = createLogger((process.env.LOG_LEVEL as any) || 'info');

const program = new Command();
program
  .name('report')
  .description('Aggregate all run results into CSV + Markdown leaderboard')
  .option('--runsDir <dir>', 'Runs directory', 'runs')
  .option('--reportsDir <dir>', 'Reports output directory', 'reports')
  .parse(process.argv);

const opts = program.opts<{ runsDir: string; reportsDir: string }>();

async function main() {
  const { paths, totalRuns } = await generateReports({ runsDir: opts.runsDir, reportsDir: opts.reportsDir });
  log.info(`Generated reports for ${totalRuns} runs`);
  console.log(
    JSON.stringify(
      {
        totalRuns,
        reports: {
          summaryCsv: paths.summaryCsv,
          leaderboardMd: paths.leaderboardMd,
          heatmapCsv: paths.heatmapCsv,
          dropoffsCsv: paths.dropoffsCsv
        }
      },
      null,
      2
    )
  );
}

main().catch((err) => {
  log.error(err?.message ?? String(err));
  process.exitCode = 1;
});
