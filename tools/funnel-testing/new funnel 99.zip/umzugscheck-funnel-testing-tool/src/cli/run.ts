#!/usr/bin/env node
import { Command } from 'commander';
import { executeRun } from '../runner/index.js';
import { createLogger } from '../shared/logger.js';

const log = createLogger((process.env.LOG_LEVEL as any) || 'info');

const program = new Command();
program
  .name('run')
  .description('Execute a run with Playwright (reads runs/<run_id>/run.config.json)')
  .requiredOption('--run_id <id>', 'Run ID (folder name under runs/)')
  .parse(process.argv);

const opts = program.opts<{ run_id: string }>();

async function main() {
  const result = await executeRun(opts.run_id);
  log.info(`Finished run_id=${result.run_id} verdict=${result.verdict} reached_success=${result.reached_success}`);
  console.log(JSON.stringify({
    run_id: result.run_id,
    verdict: result.verdict,
    reached_success: result.reached_success,
    dropoff_reason: result.dropoff_reason ?? null,
    result_path: `runs/${result.run_id}/result.json`
  }, null, 2));
}

main().catch((err) => {
  log.error(err?.message ?? String(err));
  process.exitCode = 1;
});
