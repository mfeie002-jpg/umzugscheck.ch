import path from 'node:path';
import { fileExists, readJson, writeJson } from '../shared/fs.js';
import { createRng, shuffleInPlace, stableShortHash } from '../shared/rng.js';

export interface DeckState {
  version: 1;
  deck_id: string;
  seed: string;
  created_at: string;
  cycle: number;
  order: string[];
  idx: number; // next index
}

export const DEFAULT_DECK_STATE_PATH = path.join('runs', '_state', 'deck.json');

export async function loadDeckState(statePath: string): Promise<DeckState | null> {
  if (!(await fileExists(statePath))) return null;
  const raw = await readJson<DeckState>(statePath);
  if (raw.version !== 1 || !Array.isArray(raw.order)) return null;
  return raw;
}

export async function initDeckState(statePath: string, gatewayIds: string[], deckSeed?: string): Promise<DeckState> {
  const seed = deckSeed ?? stableShortHash(`deck::${new Date().toISOString()}::${Math.random()}`, 16);
  const rng = createRng(`deck::${seed}::cycle0`);
  const order = shuffleInPlace([...gatewayIds], rng);
  const state: DeckState = {
    version: 1,
    deck_id: stableShortHash(seed, 12),
    seed,
    created_at: new Date().toISOString(),
    cycle: 0,
    order,
    idx: 0
  };
  await writeJson(statePath, state);
  return state;
}

export async function nextFromDeck(statePath: string, gatewayIds: string[]): Promise<{ gatewayId: string; state: DeckState }> {
  const existing = await loadDeckState(statePath);
  let state = existing;
  if (!state) {
    state = await initDeckState(statePath, gatewayIds);
  }

  // If gateway list changed, reconcile: keep only valid ids, append new ones at end, then reshuffle next cycle.
  const set = new Set(gatewayIds);
  state.order = state.order.filter((id) => set.has(id));
  const missing = gatewayIds.filter((id) => !state!.order.includes(id));
  if (missing.length > 0) {
    state.order.push(...missing);
  }

  if (state.idx >= state.order.length) {
    state.cycle += 1;
    const nextSeed = stableShortHash(`${state.seed}::cycle${state.cycle}`, 16);
    state.seed = nextSeed;
    const rng = createRng(`deck::${state.seed}::cycle${state.cycle}`);
    state.order = shuffleInPlace([...gatewayIds], rng);
    state.idx = 0;
  }

  const gatewayId = state.order[state.idx];
  state.idx += 1;
  await writeJson(statePath, state);
  return { gatewayId, state };
}
