import path from 'node:path';
import { z } from 'zod';
import { readJson, writeJson, ensureDir } from '../shared/fs.js';
import { createRng, pickOne, weightedPick } from '../shared/rng.js';
import {
  DispatchModeSchema,
  GatewaySchema,
  PersonaSchema,
  PathPolicySchema,
  RunConfigSchema,
  type DispatchMode,
  type Gateway,
  type Persona,
  type PathPolicy,
  type RunConfig,
  RunOptionsSchema
} from '../shared/schemas.js';
import { DEFAULT_DECK_STATE_PATH, nextFromDeck } from './deckState.js';

const GatewaysFileSchema = z.array(GatewaySchema);
const PersonasFileSchema = z.array(PersonaSchema);

export interface DispatchInput {
  run_id: string;
  seed: string;
  mode: DispatchMode;
  deckStatePath?: string;
  matchLanguage: boolean;
  options?: Partial<z.infer<typeof RunOptionsSchema>>;
  policyWeights?: Partial<Record<PathPolicy, number>>;
}

export interface DispatchOutput {
  runConfig: RunConfig;
  runDir: string;
}

export async function loadGateways(filePath = path.join('data', 'gateways.json')): Promise<Gateway[]> {
  const raw = await readJson<unknown>(filePath);
  const parsed = GatewaysFileSchema.parse(raw);
  return parsed.filter((g) => (g.enabled ?? true) !== false);
}

export async function loadPersonas(filePath = path.join('data', 'personas.json')): Promise<Persona[]> {
  const raw = await readJson<unknown>(filePath);
  const parsed = PersonasFileSchema.parse(raw);
  return parsed.filter((p) => (p.enabled ?? true) !== false);
}

function choosePolicy(rng: ReturnType<typeof createRng>, weights?: Partial<Record<PathPolicy, number>>): PathPolicy {
  const policies = PathPolicySchema.options;
  if (!weights || Object.keys(weights).length === 0) {
    return pickOne(policies, rng);
  }
  return weightedPick(policies, (p) => weights[p] ?? 0, rng);
}

export async function dispatchRun(input: DispatchInput): Promise<DispatchOutput> {
  const mode = DispatchModeSchema.parse(input.mode);
  const run_id = input.run_id;
  const seed = input.seed;

  const gateways = await loadGateways();
  const personas = await loadPersonas();

  if (gateways.length === 0) throw new Error('No enabled gateways found in data/gateways.json');
  if (personas.length === 0) throw new Error('No enabled personas found in data/personas.json');

  const rng = createRng(`${run_id}::${seed}::dispatch`);

  const deckStatePath = input.deckStatePath ?? DEFAULT_DECK_STATE_PATH;

  let gateway: Gateway;
  if (mode === 'deck') {
    const { gatewayId } = await nextFromDeck(
      deckStatePath,
      gateways.map((g) => g.gateway_id)
    );
    const found = gateways.find((g) => g.gateway_id === gatewayId);
    if (!found) throw new Error(`Deck selected unknown gateway_id=${gatewayId}`);
    gateway = found;
  } else if (mode === 'weighted') {
    gateway = weightedPick(gateways, (g) => g.priority_weight ?? 1, rng.fork('gateway'));
  } else {
    gateway = pickOne(gateways, rng.fork('gateway'));
  }

  let personaPool = personas;
  if (input.matchLanguage) {
    const filtered = personas.filter((p) => p.language === gateway.language);
    if (filtered.length > 0) personaPool = filtered;
  }
  const persona = pickOne(personaPool, rng.fork('persona'));

  const policy = choosePolicy(rng.fork('policy'), input.policyWeights);

  const options = RunOptionsSchema.parse({ ...(input.options ?? {}) });

  const runConfig: RunConfig = RunConfigSchema.parse({
    run_id,
    seed,
    created_at: new Date().toISOString(),
    dispatcher: {
      mode,
      deck_state_path: mode === 'deck' ? deckStatePath : undefined,
      note: input.matchLanguage ? 'matchLanguage=true' : 'matchLanguage=false'
    },
    assignment: {
      gateway_id: gateway.gateway_id,
      persona_id: persona.persona_id,
      policy
    },
    options
  });

  const runDir = path.join('runs', run_id);
  await ensureDir(runDir);
  await writeJson(path.join(runDir, 'run.config.json'), runConfig);

  // Persist the resolved assignment snapshot for human readability.
  await writeJson(path.join(runDir, 'assignment.snapshot.json'), {
    gateway,
    persona,
    policy
  });

  return { runConfig, runDir };
}
