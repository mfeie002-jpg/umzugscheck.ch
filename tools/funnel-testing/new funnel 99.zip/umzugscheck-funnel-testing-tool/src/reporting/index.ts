import path from 'node:path';
import { stringify } from 'csv-stringify/sync';
import { listDirs, readJson, writeText, fileExists } from '../shared/fs.js';
import { RunResultSchema, type RunResult } from '../shared/schemas.js';
import { averageScore } from '../runner/scorecard.js';

export interface ReportPaths {
  reportsDir: string;
  summaryCsv: string;
  leaderboardMd: string;
  heatmapCsv: string;
  dropoffsCsv: string;
}

export async function loadAllResults(runsDir = 'runs'): Promise<RunResult[]> {
  const runIds = await listDirs(runsDir);
  const results: RunResult[] = [];

  for (const run_id of runIds) {
    const resultPath = path.join(runsDir, run_id, 'result.json');
    if (!(await fileExists(resultPath))) continue;
    const raw = await readJson<unknown>(resultPath);
    try {
      results.push(RunResultSchema.parse(raw));
    } catch {
      // ignore invalid
    }
  }

  // Sort by time for stable output
  results.sort((a, b) => a.started_at.localeCompare(b.started_at));
  return results;
}

export async function generateReports(params: {
  runsDir?: string;
  reportsDir?: string;
} = {}): Promise<{ paths: ReportPaths; totalRuns: number; usedRuns: number }> {
  const runsDir = params.runsDir ?? 'runs';
  const reportsDir = params.reportsDir ?? 'reports';

  const results = await loadAllResults(runsDir);

  const paths: ReportPaths = {
    reportsDir,
    summaryCsv: path.join(reportsDir, 'summary.csv'),
    leaderboardMd: path.join(reportsDir, 'leaderboard.md'),
    heatmapCsv: path.join(reportsDir, 'persona_gateway_heatmap.csv'),
    dropoffsCsv: path.join(reportsDir, 'dropoffs.csv')
  };

  // Summary CSV
  const summaryRows = results.map((r) => {
    const avg = averageScore(r.scores);
    return {
      run_id: r.run_id,
      started_at: r.started_at,
      duration_ms: r.duration_ms,
      gateway_id: r.assignment.gateway_id,
      persona_id: r.assignment.persona_id,
      policy: r.assignment.policy,
      device: r.assignment.device,
      language: r.assignment.language,
      verdict: r.verdict,
      reached_success: r.reached_success,
      avg_score: avg.toFixed(2),
      intent_match: r.scores.intent_match,
      trust: r.scores.trust,
      friction: r.scores.friction,
      clarity: r.scores.clarity,
      mobile_usability: r.scores.mobile_usability,
      conversion_confidence: r.scores.conversion_confidence,
      step_count: r.step_count,
      dropoff_reason: r.dropoff_reason ?? ''
    };
  });

  const summaryCsv = stringify(summaryRows, { header: true });
  await writeText(paths.summaryCsv, summaryCsv);

  // Dropoff reasons
  const dropoffCounts = new Map<string, number>();
  for (const r of results) {
    const reason = (r.dropoff_reason ?? '').trim();
    if (!reason) continue;
    dropoffCounts.set(reason, (dropoffCounts.get(reason) ?? 0) + 1);
  }
  const dropoffRows = [...dropoffCounts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .map(([reason, count]) => ({ reason, count }));
  await writeText(paths.dropoffsCsv, stringify(dropoffRows, { header: true }));

  // Leaderboard markdown (by gateway)
  const byGateway = groupBy(results, (r) => r.assignment.gateway_id);
  const gatewayStats = Object.entries(byGateway).map(([gateway_id, rs]) => {
    const avgConv = avg(rs.map((r) => r.scores.conversion_confidence));
    const avgAll = avg(rs.map((r) => averageScore(r.scores)));
    const winners = rs.filter((r) => r.verdict === 'WINNER').length;
    const blockers = rs.filter((r) => r.verdict === 'BLOCKER').length;
    return {
      gateway_id,
      runs: rs.length,
      avg_score: avgAll,
      avg_conversion_confidence: avgConv,
      winners,
      blockers
    };
  });

  gatewayStats.sort((a, b) => b.avg_conversion_confidence - a.avg_conversion_confidence || b.avg_score - a.avg_score);

  const top = gatewayStats.slice(0, 10);
  const bottom = [...gatewayStats].sort((a, b) => a.avg_conversion_confidence - b.avg_conversion_confidence || a.avg_score - b.avg_score).slice(0, 10);

  const leaderboardMd = buildLeaderboardMarkdown({ totalRuns: results.length, top, bottom, dropoffRows });
  await writeText(paths.leaderboardMd, leaderboardMd);

  // Heatmap CSV (persona x gateway, using avg conversion_confidence)
  const personas = [...new Set(results.map((r) => r.assignment.persona_id))].sort();
  const gateways = [...new Set(results.map((r) => r.assignment.gateway_id))].sort();

  const heatmapMatrix: Array<Record<string, string>> = [];
  for (const persona_id of personas) {
    const row: Record<string, string> = { persona_id };
    for (const gateway_id of gateways) {
      const cellRuns = results.filter((r) => r.assignment.persona_id === persona_id && r.assignment.gateway_id === gateway_id);
      if (cellRuns.length === 0) {
        row[gateway_id] = '';
      } else {
        row[gateway_id] = avg(cellRuns.map((r) => r.scores.conversion_confidence)).toFixed(2);
      }
    }
    heatmapMatrix.push(row);
  }
  const heatmapCsv = stringify(heatmapMatrix, { header: true });
  await writeText(paths.heatmapCsv, heatmapCsv);

  return { paths, totalRuns: results.length, usedRuns: results.length };
}

function groupBy<T>(items: T[], key: (t: T) => string): Record<string, T[]> {
  const out: Record<string, T[]> = {};
  for (const item of items) {
    const k = key(item);
    out[k] = out[k] ?? [];
    out[k].push(item);
  }
  return out;
}

function avg(nums: number[]): number {
  if (nums.length === 0) return 0;
  return nums.reduce((a, b) => a + b, 0) / nums.length;
}

function buildLeaderboardMarkdown(params: {
  totalRuns: number;
  top: Array<{ gateway_id: string; runs: number; avg_score: number; avg_conversion_confidence: number; winners: number; blockers: number }>;
  bottom: Array<{ gateway_id: string; runs: number; avg_score: number; avg_conversion_confidence: number; winners: number; blockers: number }>;
  dropoffRows: Array<{ reason: string; count: number }>;
}): string {
  const lines: string[] = [];
  lines.push(`# Funnel Testing Leaderboard`);
  lines.push('');
  lines.push(`Total runs analyzed: **${params.totalRuns}**`);
  lines.push('');

  const table = (rows: typeof params.top) => {
    const header = `| gateway_id | runs | avg_conversion_confidence | avg_score | WINNER | BLOCKER |`;
    const sep = `|---|---:|---:|---:|---:|---:|`;
    const body = rows
      .map((r) =>
        `| ${r.gateway_id} | ${r.runs} | ${r.avg_conversion_confidence.toFixed(2)} | ${r.avg_score.toFixed(2)} | ${r.winners} | ${r.blockers} |`
      )
      .join('\n');
    return [header, sep, body].join('\n');
  };

  lines.push(`## Top gateways (by conversion confidence)`);
  lines.push('');
  lines.push(table(params.top));
  lines.push('');

  lines.push(`## Bottom gateways (by conversion confidence)`);
  lines.push('');
  lines.push(table(params.bottom));
  lines.push('');

  lines.push('## Common drop-off reasons');
  lines.push('');
  if (params.dropoffRows.length === 0) {
    lines.push('_No drop-off reasons recorded._');
  } else {
    lines.push('| reason | count |');
    lines.push('|---|---:|');
    for (const r of params.dropoffRows.slice(0, 15)) {
      lines.push(`| ${escapeMd(r.reason)} | ${r.count} |`);
    }
  }
  lines.push('');
  lines.push('---');
  lines.push('Generated by `npm run report`');
  lines.push('');
  return lines.join('\n');
}

function escapeMd(s: string): string {
  return s.replace(/\|/g, '\\|');
}
