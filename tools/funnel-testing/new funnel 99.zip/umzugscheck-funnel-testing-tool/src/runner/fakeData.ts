import { stableShortHash } from '../shared/rng.js';
import type { Persona } from '../shared/schemas.js';

export interface FakeMoveData {
  from_zip: string;
  to_zip: string;
  from_city: string;
  to_city: string;
  move_date_iso: string; // YYYY-MM-DD
  rooms: string;
  floor: string;
  name: string;
  email: string;
  phone: string;
}

export function makeFakeMoveData(params: {
  run_id: string;
  persona: Persona;
  today?: Date;
}): FakeMoveData {
  const today = params.today ?? new Date();
  const future = new Date(today.getTime());
  // deterministic future date: + (14..60) days derived from run_id
  const offsetDays = 14 + (parseInt(stableShortHash(params.run_id, 2), 16) % 47);
  future.setUTCDate(future.getUTCDate() + offsetDays);
  const yyyy = future.getUTCFullYear();
  const mm = String(future.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(future.getUTCDate()).padStart(2, '0');

  const suffix = stableShortHash(`${params.run_id}::${params.persona.persona_id}`, 6);
  const lang = params.persona.language;
  const name = lang === 'en' ? 'Test User' : lang === 'fr' ? 'Utilisateur Test' : 'Test Nutzer';

  return {
    from_zip: '8000',
    to_zip: '6300',
    from_city: 'Zürich',
    to_city: 'Zug',
    move_date_iso: `${yyyy}-${mm}-${dd}`,
    rooms: '3.5',
    floor: '2',
    name: `[TEST] ${name}`,
    email: `umzugscheck.test+${suffix}@example.com`,
    phone: '0791234567'
  };
}
