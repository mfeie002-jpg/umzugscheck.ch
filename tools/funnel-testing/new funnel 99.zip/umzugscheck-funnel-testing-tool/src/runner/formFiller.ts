import type { Page, Locator } from 'playwright';
import type { FakeMoveData } from './fakeData.js';

function normalize(s: string): string {
  return s.toLowerCase().replace(/\s+/g, ' ').trim();
}

async function getFieldMeta(locator: Locator): Promise<{
  tag: string;
  type: string | null;
  name: string | null;
  id: string | null;
  placeholder: string | null;
  ariaLabel: string | null;
  labelText: string | null;
}> {
  return locator.evaluate((el) => {
    const html = el as HTMLElement;
    const tag = html.tagName.toLowerCase();
    const input = html as HTMLInputElement;
    const type = (input.type || null) as any;
    const name = input.getAttribute('name');
    const id = input.getAttribute('id');
    const placeholder = input.getAttribute('placeholder');
    const ariaLabel = input.getAttribute('aria-label');

    let labelText: string | null = null;
    // Try associated <label for="id">
    if (id) {
      const lab = document.querySelector(`label[for="${CSS.escape(id)}"]`);
      if (lab) labelText = lab.textContent?.trim() || null;
    }
    // Try wrapping label
    if (!labelText) {
      const parentLabel = html.closest('label');
      if (parentLabel) labelText = parentLabel.textContent?.trim() || null;
    }

    return {
      tag,
      type,
      name,
      id,
      placeholder,
      ariaLabel,
      labelText
    };
  });
}

function classifyField(meta: Awaited<ReturnType<typeof getFieldMeta>>): string {
  const hay = normalize(
    [meta.labelText, meta.placeholder, meta.ariaLabel, meta.name, meta.id].filter(Boolean).join(' ')
  );
  if (/email/.test(hay)) return 'email';
  if (/telefon|phone|mobile/.test(hay)) return 'phone';
  if (/name|vorname|nachname/.test(hay)) return 'name';
  if (/plz|postleitzahl|zip/.test(hay)) return 'zip';
  if (/ort|city|stadt/.test(hay)) return 'city';
  if (/von|start|abhol|pickup|from/.test(hay)) return 'from';
  if (/nach|ziel|deliver|drop|to\b/.test(hay)) return 'to';
  if (/datum|date/.test(hay) || meta.type === 'date') return 'date';
  if (/zimmer|rooms|room/.test(hay)) return 'rooms';
  if (/etage|stock|floor/.test(hay)) return 'floor';
  if (/strasse|street|adresse|address/.test(hay)) return 'address';
  return 'unknown';
}

export async function fillKnownFields(page: Page, data: FakeMoveData): Promise<{ filled: string[]; skipped: string[] }> {
  const filled: string[] = [];
  const skipped: string[] = [];

  const fields = page.locator('input, textarea, select');
  const count = await fields.count();

  for (let i = 0; i < count; i++) {
    const field = fields.nth(i);
    if (!(await field.isVisible().catch(() => false))) continue;

    const meta = await getFieldMeta(field);
    const cls = classifyField(meta);

    // Don't overwrite already-filled fields
    const currentVal = await field.evaluate((el) => {
      const input = el as HTMLInputElement;
      if (input.tagName.toLowerCase() === 'select') return (input as any).value ?? '';
      return input.value ?? '';
    });
    if (String(currentVal).trim().length > 0) {
      skipped.push(`${cls}:already-filled`);
      continue;
    }

    try {
      if (meta.tag === 'select') {
        // Attempt to select by value/label for known fields; otherwise skip.
        if (cls === 'rooms') {
          await field.selectOption({ label: /3|3\.5|4/i }).catch(async () => {
            await field.selectOption({ index: 1 });
          });
          filled.push('rooms(select)');
        } else if (cls === 'floor') {
          await field.selectOption({ label: /2|1|0/i }).catch(async () => {
            await field.selectOption({ index: 1 });
          });
          filled.push('floor(select)');
        } else {
          skipped.push(`${cls}:select-unknown`);
        }
        continue;
      }

      if (meta.type === 'checkbox' || meta.type === 'radio') {
        skipped.push(`${cls}:checkbox-radio`);
        continue;
      }

      // Inputs/textareas
      const value = (() => {
        switch (cls) {
          case 'email':
            return data.email;
          case 'phone':
            return data.phone;
          case 'name':
            return data.name;
          case 'zip':
            // If there are multiple PLZ fields, we'll fill both with from/to based on surrounding context is hard.
            // Start with from_zip; later steps likely have separate IDs.
            return data.from_zip;
          case 'city':
            return data.from_city;
          case 'from':
          case 'address':
            return `${data.from_zip} ${data.from_city}`;
          case 'to':
            return `${data.to_zip} ${data.to_city}`;
          case 'date':
            return data.move_date_iso;
          case 'rooms':
            return data.rooms;
          case 'floor':
            return data.floor;
          default:
            return null;
        }
      })();

      if (value === null) {
        skipped.push(`${cls}:no-value`);
        continue;
      }

      await field.fill(String(value));
      filled.push(`${cls}`);
    } catch {
      skipped.push(`${cls}:fill-failed`);
    }
  }

  return { filled, skipped };
}
