import type { Page, ElementHandle } from 'playwright';

export interface ClickCandidate {
  handle: ElementHandle<HTMLElement>;
  label: string;
  kind: 'button' | 'link' | 'other';
  bbox: { x: number; y: number; width: number; height: number };
  score: number;
  href?: string;
}

const CTA_KEYWORDS = [
  /offerte|offerten|angebot|anfrage|fixpreis|preis|berechnen/i,
  /jetzt|start|weiter|continue|go|los/i,
  /gratis|kostenlos/free/i,
  /send|absenden|senden|submit/i
];

const ESCAPE_KEYWORDS = [
  /zurück|abbrechen|schliessen|schließen|close|dismiss/i,
  /home|startseite|impressum|datenschutz|privacy/i,
  /faq|hilfe|kontakt|about/i
];

export function isOnSameSite(url: string, baseHost: string): boolean {
  try {
    const u = new URL(url);
    return u.host === baseHost;
  } catch {
    return false;
  }
}

export async function detectSuccess(page: Page): Promise<{ success: boolean; hint?: string }> {
  const url = page.url();
  if (/danke|thank|merci|success|best[aä]tigt|confirmation/i.test(url)) {
    return { success: true, hint: `URL matched success pattern: ${url}` };
  }
  // Look for common success copy
  const bodyText = await page.evaluate(() => document.body?.innerText?.slice(0, 8000) ?? '');
  if (/(vielen\s+dank|danke|thank\s+you|merci|anfrage.*(gesendet|erhalten)|wir\s+melden\s+uns|best[aä]tigung)/i.test(bodyText)) {
    return { success: true, hint: 'Body text matched success pattern' };
  }
  return { success: false };
}

export async function detectBlockingError(page: Page): Promise<string | null> {
  const bodyText = await page.evaluate(() => document.body?.innerText?.slice(0, 6000) ?? '');
  if (/(502\s+bad\s+gateway|503\s+service|504\s+gateway|something\s+went\s+wrong|server\s+error|internal\s+server\s+error)/i.test(bodyText)) {
    return 'Server error page detected';
  }
  if (/(access\s+denied|forbidden|captcha|bot\s+detected)/i.test(bodyText)) {
    return 'Access blocked (captcha/bot detection)';
  }
  return null;
}

export async function detectFrictionSignals(page: Page): Promise<string[]> {
  const signals: string[] = [];

  // Horizontal overflow (mobile pain)
  const hasOverflow = await page.evaluate(() => {
    const doc = document.documentElement;
    return doc.scrollWidth > doc.clientWidth + 2;
  });
  if (hasOverflow) signals.push('Horizontal overflow detected (likely mobile layout issue)');

  // Visible validation errors
  const errLoc = page.locator(
    'text=/Pflichtfeld|erforderlich|required|ungültig|invalid|Fehler|Error|bitte\s+ausfüllen|please\s+fill/i'
  );
  const errCount = await errLoc.count().catch(() => 0);
  if (errCount > 0) signals.push(`Validation/error copy visible (${errCount} matches)`);

  return signals;
}

export async function detectTrustSignals(page: Page): Promise<string[]> {
  const text = await page.evaluate(() => document.body?.innerText?.slice(0, 12000) ?? '');
  const found: string[] = [];
  const patterns: Array<[RegExp, string]> = [
    [/google\s+reviews|google\s+bewert/i, 'Google Reviews mentioned'],
    [/\btrust\b|vertrauen|trusted|sicher/i, 'Trust language present'],
    [/\bssl\b|https/i, 'SSL/HTTPS mentioned'],
    [/\b4\.\d\b|\b5\.0\b|★|⭐/i, 'Star rating / score shown'],
    [/schweiz|swiss|suisse/i, 'Swiss positioning mentioned'],
    [/gepr[üu]ft|verifiziert|certified|zertifiz/i, 'Verified/Certified mentioned']
  ];
  for (const [re, label] of patterns) {
    if (re.test(text)) found.push(label);
  }
  return found;
}

async function getLabel(handle: ElementHandle<HTMLElement>): Promise<string> {
  return handle.evaluate((el) => {
    const txt = (el.innerText || (el as any).value || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
    return txt.replace(/\s+/g, ' ').slice(0, 120);
  });
}

async function getHref(handle: ElementHandle<HTMLElement>): Promise<string | undefined> {
  return handle.evaluate((el) => {
    const tag = el.tagName.toLowerCase();
    if (tag !== 'a') return undefined;
    const a = el as HTMLAnchorElement;
    return a.href || undefined;
  });
}

function scoreCandidate(label: string, bbox: { x: number; y: number; width: number; height: number }): number {
  const area = Math.max(0, bbox.width) * Math.max(0, bbox.height);
  const keywordBoost = CTA_KEYWORDS.some((re) => re.test(label)) ? 2.0 : 1.0;
  const len = label.length;
  const hasText = len > 0 ? 1.0 : 0.3;
  const yBoost = bbox.y < 600 ? 1.2 : 1.0; // above-the-fold slightly better
  return area * keywordBoost * hasText * yBoost;
}

export async function collectClickCandidates(page: Page): Promise<ClickCandidate[]> {
  const handles = (await page.$$('button, a, [role="button"], input[type="submit"], input[type="button"]')) as ElementHandle<HTMLElement>[];
  const viewport = page.viewportSize() ?? { width: 1280, height: 720 };

  const out: ClickCandidate[] = [];
  for (const h of handles) {
    const bbox = await h.boundingBox();
    if (!bbox) continue;
    if (bbox.width < 24 || bbox.height < 18) continue;

    // Rough visible-in-viewport check
    const inView = bbox.x + bbox.width > 0 && bbox.y + bbox.height > 0 && bbox.x < viewport.width && bbox.y < viewport.height;
    if (!inView) continue;

    const label = await getLabel(h);
    const href = await getHref(h);

    // Exclude obviously non-navigation URIs
    if (href && /^(mailto:|tel:|javascript:)/i.test(href)) continue;

    const kind: ClickCandidate['kind'] = href ? 'link' : 'button';
    out.push({
      handle: h,
      label,
      kind,
      bbox,
      href,
      score: scoreCandidate(label, bbox)
    });
  }

  // Best effort: ensure stable ordering
  out.sort((a, b) => b.score - a.score || a.bbox.y - b.bbox.y || a.label.localeCompare(b.label));
  return out;
}

export async function detectPrimarySecondaryEscape(page: Page): Promise<{
  main?: ClickCandidate;
  secondary?: ClickCandidate;
  escape?: ClickCandidate;
  all: ClickCandidate[];
}> {
  const all = await collectClickCandidates(page);

  const main = all[0];
  const secondary = all.find((c) => c !== main) || undefined;

  // Escape: keyword match preferred; otherwise choose a small/top-left link
  const escapeByKeyword = all.find((c) => ESCAPE_KEYWORDS.some((re) => re.test(c.label)));
  let escape = escapeByKeyword;
  if (!escape) {
    // choose a candidate near top-left that is NOT main
    const sorted = [...all].sort((a, b) => {
      const aScore = a.bbox.y * 2 + a.bbox.x;
      const bScore = b.bbox.y * 2 + b.bbox.x;
      return aScore - bScore;
    });
    escape = sorted.find((c) => c !== main) || undefined;
  }

  return { main, secondary, escape, all };
}

export function looksLikeFinalSubmit(label: string): boolean {
  return /(absenden|senden|submit|offerte\s+anfordern|anfrage\s+senden|offerten\s+erhalten|jetzt\s+anfragen)/i.test(label);
}
