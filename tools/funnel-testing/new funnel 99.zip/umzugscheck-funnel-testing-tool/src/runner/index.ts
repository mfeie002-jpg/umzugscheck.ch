import path from 'node:path';
import { chromium, devices, type Browser, type BrowserContext, type Page } from 'playwright';

import {
  RunConfigSchema,
  RunResultSchema,
  normalizeWeights,
  type Gateway,
  type Persona,
  type RunConfig,
  type RunResult,
  type StepEvent
} from '../shared/schemas.js';
import { readJson, writeJson, ensureDir, safeBasename } from '../shared/fs.js';
import { createLogger } from '../shared/logger.js';
import { createRng } from '../shared/rng.js';
import { loadGateways, loadPersonas } from '../dispatcher/index.js';
import { makeFakeMoveData } from './fakeData.js';
import { fillKnownFields } from './formFiller.js';
import {
  detectBlockingError,
  detectFrictionSignals,
  detectPrimarySecondaryEscape,
  detectSuccess,
  detectTrustSignals,
  looksLikeFinalSubmit
} from './heuristics.js';
import { computeScorecard, computeVerdict } from './scorecard.js';

const log = createLogger((process.env.LOG_LEVEL as any) || 'info');

function localeForLanguage(lang: 'de' | 'en' | 'fr'): string {
  if (lang === 'de') return 'de-CH';
  if (lang === 'fr') return 'fr-CH';
  return 'en-US';
}

async function screenshot(page: Page, screenshotsDir: string, idx: number, label: string): Promise<string> {
  const name = `${String(idx).padStart(2, '0')}-${safeBasename(label)}.png`;
  const abs = path.join(screenshotsDir, name);
  await page.screenshot({ path: abs, fullPage: true }).catch(() => undefined);
  return path.join('screenshots', name);
}

async function getH1(page: Page): Promise<string | undefined> {
  const h1 = page.locator('h1').first();
  if (!(await h1.count().catch(() => 0))) return undefined;
  const txt = await h1.innerText().catch(() => '');
  const cleaned = txt.replace(/\s+/g, ' ').trim();
  return cleaned || undefined;
}

async function safeBodyText(page: Page, maxLen = 8000): Promise<string> {
  const t = await page.evaluate(() => document.body?.innerText ?? '');
  return String(t).replace(/\s+/g, ' ').trim().slice(0, maxLen);
}

function pickActionKind(params: {
  policy: RunConfig['assignment']['policy'];
  weights: { main: number; secondary: number; escape: number };
  rng: ReturnType<typeof createRng>;
}): 'main' | 'secondary' | 'escape' {
  const { policy, weights, rng } = params;
  if (policy === 'StrictMain') return 'main';

  if (policy === 'ChaosMonkey') {
    // ChaosMonkey: mostly weighted, sometimes escape-y
    const chaos = rng.next();
    if (chaos < 0.15) return 'escape';
    if (chaos < 0.55) return 'main';
    return 'secondary';
  }

  // RealisticWeighted
  const x = rng.next();
  if (x < weights.main) return 'main';
  if (x < weights.main + weights.secondary) return 'secondary';
  return 'escape';
}

function dropoffFromContext(ctx: {
  leftSite: boolean;
  dryRunReachedSubmit: boolean;
  blocker?: string;
  maxedOut: boolean;
}): string | undefined {
  if (ctx.blocker) return ctx.blocker;
  if (ctx.dryRunReachedSubmit) return 'Dry run: reached final submit CTA, stopped before submission';
  if (ctx.leftSite) return 'User escaped funnel (left site)';
  if (ctx.maxedOut) return 'Max steps/time reached without a clear submission/success';
  return undefined;
}

export async function loadRunConfig(runDirOrId: string): Promise<{ config: RunConfig; runDir: string }> {
  const runDir = runDirOrId.includes(path.sep) ? runDirOrId : path.join('runs', runDirOrId);
  const configPath = path.join(runDir, 'run.config.json');
  const raw = await readJson<unknown>(configPath);
  const config = RunConfigSchema.parse(raw);
  return { config, runDir };
}

export async function executeRun(runDirOrId: string): Promise<RunResult> {
  const { config, runDir } = await loadRunConfig(runDirOrId);

  const gateways = await loadGateways();
  const personas = await loadPersonas();
  const gateway = gateways.find((g) => g.gateway_id === config.assignment.gateway_id);
  const persona = personas.find((p) => p.persona_id === config.assignment.persona_id);
  if (!gateway) throw new Error(`gateway_id not found: ${config.assignment.gateway_id}`);
  if (!persona) throw new Error(`persona_id not found: ${config.assignment.persona_id}`);

  const landingUrl = gateway.landing_url;
  const baseHost = new URL(landingUrl).host;

  const screenshotsDir = path.join(runDir, 'screenshots');
  await ensureDir(screenshotsDir);

  const harPath = config.options.enableHar ? path.join(runDir, 'network.har') : undefined;
  const traceZip = config.options.enableTrace ? path.join(runDir, 'trace.zip') : undefined;

  const steps: StepEvent[] = [];
  const frictionPoints: string[] = [];
  let dryRunReachedSubmit = false;
  let leftSite = false;
  let blocker: string | undefined;

  const startedAt = new Date();

  const rng = createRng(`${config.run_id}::${config.seed}::run`);
  const fakeData = makeFakeMoveData({ run_id: config.run_id, persona });
  const clickWeights = normalizeWeights(persona.click_bias_weights);

  let browser: Browser | null = null;
  let context: BrowserContext | null = null;
  try {
    browser = await chromium.launch({ headless: config.options.headless });

    const deviceOpts = persona.device === 'mobile' ? devices['iPhone 12'] : undefined;
    context = await browser.newContext({
      ...(deviceOpts ?? {}),
      locale: localeForLanguage(persona.language),
      timezoneId: 'Europe/Zurich',
      recordHar: harPath ? { path: harPath, content: 'embed', mode: 'full' } : undefined
    });

    if (config.options.enableTrace) {
      await context.tracing.start({ screenshots: true, snapshots: true, sources: false });
    }

    const page = await context.newPage();
    page.setDefaultTimeout(config.options.stepTimeoutMs);

    const pushStep = (event: StepEvent) => steps.push(event);

    pushStep({
      idx: 0,
      ts: new Date().toISOString(),
      url: landingUrl,
      action: { kind: 'goto', label: landingUrl }
    });

    await page.goto(landingUrl, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(800);

    const shot0 = await screenshot(page, screenshotsDir, 0, 'landing');
    pushStep({
      idx: 0,
      ts: new Date().toISOString(),
      url: page.url(),
      action: { kind: 'wait', label: 'post-load' },
      screenshot: shot0
    });

    // 10-second test evaluation
    const title = await page.title().catch(() => undefined);
    const h1 = await getH1(page);
    const trustSignalsFound = await detectTrustSignals(page);
    const topCtas = await detectPrimarySecondaryEscape(page);

    const tenSecond = {
      title,
      h1,
      top_ctas: [
        topCtas.main ? { label: topCtas.main.label, kind: 'main' as const, confidence: 0.8 } : null,
        topCtas.secondary ? { label: topCtas.secondary.label, kind: 'secondary' as const, confidence: 0.6 } : null,
        topCtas.escape ? { label: topCtas.escape.label, kind: 'escape' as const, confidence: 0.5 } : null
      ].filter(Boolean) as any,
      trust_signals_found: trustSignalsFound,
      issues: [] as string[]
    };

    // Main loop
    const startedMs = Date.now();
    for (let stepIdx = 1; stepIdx <= config.options.maxSteps; stepIdx++) {
      if (Date.now() - startedMs > config.options.maxTimeMs) {
        break;
      }

      const url = page.url();
      if (!isSameHost(url, baseHost)) {
        leftSite = true;
        break;
      }

      const blockerHint = await detectBlockingError(page);
      if (blockerHint) {
        blocker = blockerHint;
        break;
      }

      const success = await detectSuccess(page);
      if (success.success) {
        pushStep({
          idx: stepIdx,
          ts: new Date().toISOString(),
          url,
          action: { kind: 'stop', label: 'success' },
          notes: success.hint ? [success.hint] : undefined
        });
        break;
      }

      const fillRes = await fillKnownFields(page, fakeData);
      if (fillRes.filled.length > 0) {
        pushStep({
          idx: stepIdx,
          ts: new Date().toISOString(),
          url,
          action: { kind: 'fill', label: fillRes.filled.join(',') },
          notes: fillRes.skipped.length ? [`skipped: ${fillRes.skipped.slice(0, 6).join(', ')}${fillRes.skipped.length > 6 ? '…' : ''}`] : undefined
        });
      }

      const friction = await detectFrictionSignals(page);
      for (const f of friction) frictionPoints.push(f);

      const shot = await screenshot(page, screenshotsDir, stepIdx, `step-${stepIdx}`);

      const actions = await detectPrimarySecondaryEscape(page);

      const actionKind = pickActionKind({ policy: config.assignment.policy, weights: clickWeights, rng: rng.fork(`step${stepIdx}`) });
      const chosen =
        actionKind === 'main'
          ? actions.main ?? actions.secondary
          : actionKind === 'secondary'
            ? actions.secondary ?? actions.main
            : actions.escape ?? actions.secondary ?? actions.main;

      if (!chosen) {
        blocker = 'No clickable actions detected (stuck UI / selector heuristics failed)';
        pushStep({
          idx: stepIdx,
          ts: new Date().toISOString(),
          url,
          action: { kind: 'error', label: blocker },
          screenshot: shot
        });
        break;
      }

      // Dry-run safety: stop at submit CTA
      if (config.options.dryRun && looksLikeFinalSubmit(chosen.label)) {
        dryRunReachedSubmit = true;
        pushStep({
          idx: stepIdx,
          ts: new Date().toISOString(),
          url,
          action: { kind: 'stop', label: 'dry-run reached submit CTA' },
          screenshot: shot,
          notes: [
            `Detected likely final submit CTA: "${chosen.label}"`,
            'Set options.dryRun=false (or dispatch with --submit) to allow actual submission.'
          ]
        });
        break;
      }

      pushStep({
        idx: stepIdx,
        ts: new Date().toISOString(),
        url,
        action: { kind: 'click', label: chosen.label, details: { kind: actionKind } },
        screenshot: shot
      });

      const prevUrl = page.url();
      await chosen.handle.click({ timeout: config.options.stepTimeoutMs }).catch((err) => {
        blocker = `Click failed: ${String(err?.message ?? err)}`;
      });
      if (blocker) break;

      // Wait for navigation / SPA update
      await page.waitForLoadState('domcontentloaded', { timeout: config.options.stepTimeoutMs }).catch(() => undefined);
      await page.waitForTimeout(450);

      const newUrl = page.url();
      if (newUrl !== prevUrl) {
        pushStep({
          idx: stepIdx,
          ts: new Date().toISOString(),
          url: newUrl,
          action: { kind: 'navigate', label: `${prevUrl} -> ${newUrl}` }
        });
      }
    }

    const reachedSuccess = (await detectSuccess(page)).success;
    const endedAt = new Date();

    // Stop trace
    const bodyText = await safeBodyText(page).catch(() => '');
    const intentText = [title, h1, bodyText].filter(Boolean).join(' | ');

    // Stop trace
    if (config.options.enableTrace && traceZip) {
      await context.tracing.stop({ path: traceZip });
    }

    const scores = computeScorecard({
      intentText,
      intentTarget: gateway.intent,
      trustSignalsFound: trustSignalsFound,
      frictionSignals: frictionPoints,
      stepCount: steps.length,
      reachedSuccess,
      dryRunReachedSubmit,
      device: persona.device
    });

    const verdict = computeVerdict(scores, reachedSuccess, Boolean(blocker));

    const result: RunResult = RunResultSchema.parse({
      run_id: config.run_id,
      seed: config.seed,
      started_at: startedAt.toISOString(),
      finished_at: endedAt.toISOString(),
      duration_ms: endedAt.getTime() - startedAt.getTime(),
      assignment: {
        gateway_id: gateway.gateway_id,
        persona_id: persona.persona_id,
        policy: config.assignment.policy,
        landing_url: landingUrl,
        device: persona.device,
        language: persona.language
      },
      artifacts: {
        run_dir: runDir,
        screenshots_dir: screenshotsDir,
        trace_zip: traceZip ? path.relative(runDir, traceZip) : undefined,
        har_path: harPath ? path.relative(runDir, harPath) : undefined
      },
      ten_second_test: tenSecond,
      steps,
      friction_points: frictionPoints,
      step_count: steps.length,
      reached_success: reachedSuccess,
      scores,
      verdict,
      dropoff_reason: dropoffFromContext({
        leftSite,
        dryRunReachedSubmit,
        blocker,
        maxedOut: !reachedSuccess && !dryRunReachedSubmit && !leftSite && !blocker
      }),
      fix_recommendation: recommendationFromSignals({ blocker, frictionPoints, leftSite })
    });

    await writeJson(path.join(runDir, 'result.json'), result);
    return result;
  } catch (err: any) {
    const endedAt = new Date();
    const result: RunResult = RunResultSchema.parse({
      run_id: config.run_id,
      seed: config.seed,
      started_at: startedAt.toISOString(),
      finished_at: endedAt.toISOString(),
      duration_ms: endedAt.getTime() - startedAt.getTime(),
      assignment: {
        gateway_id: gateway.gateway_id,
        persona_id: persona.persona_id,
        policy: config.assignment.policy,
        landing_url: gateway.landing_url,
        device: persona.device,
        language: persona.language
      },
      artifacts: {
        run_dir: runDir,
        screenshots_dir: path.join(runDir, 'screenshots')
      },
      ten_second_test: { top_ctas: [], trust_signals_found: [], issues: [] },
      steps,
      friction_points: frictionPoints,
      step_count: steps.length,
      reached_success: false,
      scores: {
        intent_match: 1,
        trust: 1,
        friction: 1,
        clarity: 1,
        mobile_usability: 1,
        conversion_confidence: 1
      },
      verdict: 'BLOCKER',
      dropoff_reason: String(err?.message ?? err),
      fix_recommendation: 'Investigate run crash; see error stack in result.json',
      error: {
        type: err?.name ?? 'Error',
        message: String(err?.message ?? err),
        stack: err?.stack ? String(err.stack) : undefined
      }
    });

    await ensureDir(runDir);
    await writeJson(path.join(runDir, 'result.json'), result);
    log.error(`Run crashed: ${String(err?.message ?? err)}`);
    return result;
  } finally {
    // if context exists, best effort close
    if (context) {
      await context.close().catch(() => undefined);
    }
    if (browser) {
      await browser.close().catch(() => undefined);
    }
  }
}

function isSameHost(url: string, baseHost: string): boolean {
  try {
    const u = new URL(url);
    return u.host === baseHost;
  } catch {
    return false;
  }
}

function recommendationFromSignals(params: {
  blocker?: string;
  frictionPoints: string[];
  leftSite: boolean;
}): string | undefined {
  if (params.blocker) {
    if (/captcha|bot/i.test(params.blocker)) return 'Consider bot-friendly testing: lower speed, add delays, or whitelist CI IP.';
    if (/server error/i.test(params.blocker)) return 'Check server health / deployment; add monitoring and rollback plan.';
    if (/No clickable actions/i.test(params.blocker)) return 'Add stable accessibility roles/labels to primary CTA; avoid dynamic-only click handlers.';
    return 'Fix blocker: ensure funnel can proceed without manual intervention.';
  }

  const overflow = params.frictionPoints.some((f) => f.toLowerCase().includes('horizontal overflow'));
  const validation = params.frictionPoints.some((f) => f.toLowerCase().includes('validation'));
  if (overflow) return 'Fix mobile layout overflow (safe area, responsive widths, remove horizontal scroll).';
  if (validation) return 'Improve form validation UX: clearer inline hints, fewer required fields per step, preserve input on errors.';
  if (params.leftSite) return 'Reduce escape routes: de-emphasize header links during funnel, keep user in enclosed checkout.';
  return undefined;
}
