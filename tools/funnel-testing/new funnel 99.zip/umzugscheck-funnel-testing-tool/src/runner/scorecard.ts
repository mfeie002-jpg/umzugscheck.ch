import type { Scorecard, Verdict } from '../shared/schemas.js';

export function clampScore(n: number): number {
  const v = Math.round(n);
  return Math.min(5, Math.max(1, v));
}

export function computeScorecard(params: {
  intentText: string;
  intentTarget: string;
  trustSignalsFound: string[];
  frictionSignals: string[];
  stepCount: number;
  reachedSuccess: boolean;
  dryRunReachedSubmit: boolean;
  device: 'mobile' | 'desktop';
}): Scorecard {
  const intentMatchRaw = (() => {
    const target = params.intentTarget.toLowerCase();
    const text = params.intentText.toLowerCase();
    if (!target) return 3;
    const words = target.split(/\W+/).filter((w) => w.length > 3);
    if (words.length === 0) return 3;
    const hits = words.filter((w) => text.includes(w)).length;
    return 1 + (4 * hits) / Math.min(words.length, 4);
  })();

  const trustRaw = Math.min(5, 1 + params.trustSignalsFound.length * 0.8);

  // Friction: fewer signals and fewer steps => higher
  const frictionPenalty = params.frictionSignals.length * 0.9 + Math.max(0, params.stepCount - 8) * 0.12;
  const frictionRaw = 5 - frictionPenalty;

  const clarityRaw = (() => {
    // heuristic: lots of steps without success suggests confusion
    if (params.reachedSuccess) return 4.5;
    if (params.stepCount <= 6) return 3.8;
    if (params.stepCount <= 10) return 3.2;
    return 2.6;
  })();

  const mobileRaw = (() => {
    if (params.device === 'desktop') return 4;
    // On mobile, any friction signal mentioning overflow is a big hit
    const overflow = params.frictionSignals.some((s) => s.toLowerCase().includes('horizontal overflow'));
    return overflow ? 2.2 : 3.8;
  })();

  const conversionRaw = (() => {
    if (params.reachedSuccess) return 5;
    if (params.dryRunReachedSubmit) return 4.2;
    // If user did lots of steps but never reached success, confidence drops.
    if (params.stepCount <= 4) return 3.3;
    if (params.stepCount <= 8) return 2.8;
    return 2.0;
  })();

  return {
    intent_match: clampScore(intentMatchRaw),
    trust: clampScore(trustRaw),
    friction: clampScore(frictionRaw),
    clarity: clampScore(clarityRaw),
    mobile_usability: clampScore(mobileRaw),
    conversion_confidence: clampScore(conversionRaw)
  };
}

export function computeVerdict(scores: Scorecard, reachedSuccess: boolean, hadBlocker: boolean): Verdict {
  if (hadBlocker) return 'BLOCKER';

  const avg =
    (scores.intent_match + scores.trust + scores.friction + scores.clarity + scores.mobile_usability + scores.conversion_confidence) / 6;

  if (reachedSuccess && avg >= 4.2 && scores.friction >= 4) return 'WINNER';
  if (avg >= 3.4) return 'PROMISING';
  return 'FAIL';
}

export function averageScore(scores: Scorecard): number {
  return (scores.intent_match + scores.trust + scores.friction + scores.clarity + scores.mobile_usability + scores.conversion_confidence) / 6;
}
