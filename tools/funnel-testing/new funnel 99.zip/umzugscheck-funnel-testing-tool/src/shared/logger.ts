export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const LEVEL_ORDER: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40
};

export function createLogger(minLevel: LogLevel = (process.env.LOG_LEVEL as LogLevel) || 'info') {
  const min = LEVEL_ORDER[minLevel] ?? LEVEL_ORDER.info;
  const log = (level: LogLevel, msg: string, meta?: unknown) => {
    if ((LEVEL_ORDER[level] ?? 100) < min) return;
    const prefix = `[${new Date().toISOString()}] ${level.toUpperCase()}`;
    // eslint-disable-next-line no-console
    if (meta === undefined) console.log(prefix, msg);
    else console.log(prefix, msg, meta);
  };
  return {
    debug: (msg: string, meta?: unknown) => log('debug', msg, meta),
    info: (msg: string, meta?: unknown) => log('info', msg, meta),
    warn: (msg: string, meta?: unknown) => log('warn', msg, meta),
    error: (msg: string, meta?: unknown) => log('error', msg, meta)
  };
}
