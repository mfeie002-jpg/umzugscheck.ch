import crypto from 'node:crypto';

export interface Rng {
  /** Returns float in [0, 1) */
  next: () => number;
  /** Returns integer in [min, max] (inclusive) */
  int: (min: number, max: number) => number;
  /** Returns true with probability p */
  chance: (p: number) => boolean;
  /** Deterministically derive a child RNG (useful per-step) */
  fork: (salt: string) => Rng;
  /** Debug info */
  seed: string;
}

function hashToUint32(input: string): number {
  const digest = crypto.createHash('sha256').update(input).digest();
  // take first 4 bytes big-endian
  return digest.readUInt32BE(0);
}

function mulberry32(a: number): () => number {
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function createRng(seed: string): Rng {
  const base = hashToUint32(seed);
  const nextRaw = mulberry32(base);
  return {
    seed,
    next: () => nextRaw(),
    int: (min: number, max: number) => {
      if (!Number.isFinite(min) || !Number.isFinite(max)) {
        throw new Error(`rng.int: non-finite bounds: ${min}, ${max}`);
      }
      if (max < min) [min, max] = [max, min];
      const r = nextRaw();
      const span = max - min + 1;
      return min + Math.floor(r * span);
    },
    chance: (p: number) => {
      if (p <= 0) return false;
      if (p >= 1) return true;
      return nextRaw() < p;
    },
    fork: (salt: string) => createRng(`${seed}::${salt}`)
  };
}

export function shuffleInPlace<T>(arr: T[], rng: Rng): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = rng.int(0, i);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

export function pickOne<T>(arr: T[], rng: Rng): T {
  if (arr.length === 0) throw new Error('pickOne: empty array');
  return arr[rng.int(0, arr.length - 1)];
}

export function weightedPick<T>(arr: T[], weightOf: (item: T) => number, rng: Rng): T {
  if (arr.length === 0) throw new Error('weightedPick: empty array');
  const weights = arr.map((i) => {
    const w = weightOf(i);
    return Number.isFinite(w) && w > 0 ? w : 0;
  });
  const total = weights.reduce((a, b) => a + b, 0);
  if (total <= 0) {
    // fallback to uniform
    return pickOne(arr, rng);
  }
  let x = rng.next() * total;
  for (let i = 0; i < arr.length; i++) {
    x -= weights[i];
    if (x <= 0) return arr[i];
  }
  return arr[arr.length - 1];
}

export function stableShortHash(input: string, length = 8): string {
  const hex = crypto.createHash('sha256').update(input).digest('hex');
  return hex.slice(0, length);
}

export function generateRunId(now: Date = new Date()): string {
  // e.g. 2026-01-28T20:25:00.123Z -> 20260128-202500-<hash>
  const pad = (n: number, w = 2) => String(n).padStart(w, '0');
  const yyyy = now.getUTCFullYear();
  const mm = pad(now.getUTCMonth() + 1);
  const dd = pad(now.getUTCDate());
  const hh = pad(now.getUTCHours());
  const mi = pad(now.getUTCMinutes());
  const ss = pad(now.getUTCSeconds());
  const base = `${yyyy}${mm}${dd}-${hh}${mi}${ss}`;
  // add a short non-deterministic suffix to reduce collisions
  const rand = crypto.randomBytes(8).toString('hex');
  const suffix = stableShortHash(`${base}:${rand}`, 6);
  return `${base}-${suffix}`;
}
