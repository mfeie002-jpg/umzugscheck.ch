import { z } from 'zod';

export const GatewaySchema = z.object({
  gateway_id: z.string().min(1),
  keyword_cluster: z.string().min(1),
  landing_url: z.string().url(),
  intent: z.string().min(1),
  language: z.enum(['de', 'en', 'fr']),
  priority_weight: z.number().positive().optional(),
  enabled: z.boolean().optional().default(true)
});

export type Gateway = z.infer<typeof GatewaySchema>;

export const PersonaSchema = z.object({
  persona_id: z.string().min(1),
  name: z.string().min(1),
  traits: z.array(z.string().min(1)).default([]),
  budget: z.union([z.enum(['low', 'medium', 'high']), z.number().nonnegative()]).optional(),
  urgency: z.number().min(1).max(5),
  trust_level: z.number().min(1).max(5),
  device: z.enum(['mobile', 'desktop']),
  language: z.enum(['de', 'en', 'fr']),
  click_bias_weights: z.object({
    main: z.number().min(0).max(1),
    secondary: z.number().min(0).max(1),
    escape: z.number().min(0).max(1)
  }),
  enabled: z.boolean().optional().default(true)
});

export type Persona = z.infer<typeof PersonaSchema>;

export const PathPolicySchema = z.enum(['StrictMain', 'RealisticWeighted', 'ChaosMonkey']);
export type PathPolicy = z.infer<typeof PathPolicySchema>;

export const DispatchModeSchema = z.enum(['deck', 'random', 'weighted']);
export type DispatchMode = z.infer<typeof DispatchModeSchema>;

export const RunOptionsSchema = z.object({
  headless: z.boolean().default(true),
  enableTrace: z.boolean().default(false),
  enableHar: z.boolean().default(false),
  dryRun: z.boolean().default(true),
  maxSteps: z.number().int().positive().default(25),
  maxTimeMs: z.number().int().positive().default(120_000),
  stepTimeoutMs: z.number().int().positive().default(15_000)
});

export type RunOptions = z.infer<typeof RunOptionsSchema>;

export const RunConfigSchema = z.object({
  run_id: z.string().min(1),
  seed: z.string().min(1),
  created_at: z.string().datetime(),
  dispatcher: z.object({
    mode: DispatchModeSchema,
    deck_state_path: z.string().optional(),
    note: z.string().optional()
  }),
  assignment: z.object({
    gateway_id: z.string(),
    persona_id: z.string(),
    policy: PathPolicySchema
  }),
  options: RunOptionsSchema
});

export type RunConfig = z.infer<typeof RunConfigSchema>;

export const ScorecardSchema = z.object({
  intent_match: z.number().min(1).max(5),
  trust: z.number().min(1).max(5),
  friction: z.number().min(1).max(5),
  clarity: z.number().min(1).max(5),
  mobile_usability: z.number().min(1).max(5),
  conversion_confidence: z.number().min(1).max(5)
});
export type Scorecard = z.infer<typeof ScorecardSchema>;

export const VerdictSchema = z.enum(['WINNER', 'PROMISING', 'FAIL', 'BLOCKER']);
export type Verdict = z.infer<typeof VerdictSchema>;

export const StepEventSchema = z.object({
  idx: z.number().int().nonnegative(),
  ts: z.string().datetime(),
  url: z.string().url().optional(),
  action: z.object({
    kind: z.enum(['goto', 'click', 'fill', 'select', 'wait', 'navigate', 'stop', 'error']),
    label: z.string().optional(),
    details: z.record(z.any()).optional()
  }),
  screenshot: z.string().optional(),
  notes: z.array(z.string()).optional()
});
export type StepEvent = z.infer<typeof StepEventSchema>;

export const RunResultSchema = z.object({
  run_id: z.string(),
  seed: z.string(),
  started_at: z.string().datetime(),
  finished_at: z.string().datetime(),
  duration_ms: z.number().int().nonnegative(),
  assignment: z.object({
    gateway_id: z.string(),
    persona_id: z.string(),
    policy: PathPolicySchema,
    landing_url: z.string().url(),
    device: z.enum(['mobile', 'desktop']),
    language: z.enum(['de', 'en', 'fr'])
  }),
  artifacts: z.object({
    run_dir: z.string(),
    screenshots_dir: z.string(),
    trace_zip: z.string().optional(),
    har_path: z.string().optional()
  }),
  ten_second_test: z
    .object({
      title: z.string().optional(),
      h1: z.string().optional(),
      top_ctas: z
        .array(
          z.object({
            label: z.string(),
            kind: z.enum(['main', 'secondary', 'escape']),
            confidence: z.number().min(0).max(1)
          })
        )
        .default([]),
      trust_signals_found: z.array(z.string()).default([]),
      issues: z.array(z.string()).default([])
    })
    .default({ top_ctas: [], trust_signals_found: [], issues: [] }),
  steps: z.array(StepEventSchema),
  friction_points: z.array(z.string()).default([]),
  step_count: z.number().int().nonnegative(),
  reached_success: z.boolean(),
  scores: ScorecardSchema,
  verdict: VerdictSchema,
  dropoff_reason: z.string().optional(),
  fix_recommendation: z.string().optional(),
  error: z
    .object({
      type: z.string(),
      message: z.string(),
      stack: z.string().optional()
    })
    .optional()
});

export type RunResult = z.infer<typeof RunResultSchema>;

export function normalizeWeights(w: { main: number; secondary: number; escape: number }): {
  main: number;
  secondary: number;
  escape: number;
} {
  const sum = w.main + w.secondary + w.escape;
  if (sum <= 0) return { main: 1, secondary: 0, escape: 0 };
  return { main: w.main / sum, secondary: w.secondary / sum, escape: w.escape / sum };
}
